# Nameless-Store

## Requirements
- NamelessMC version 2.1.0

## Installation:
- Upload the contents of the **upload** directory straight into your NamelessMC installation's directory
- Activate the module in the StaffCP -> Modules tab
- Install the Nameless Plugin on your server [https://www.spigotmc.org/resources/nameless-plugin-for-v2.59032/](https://www.spigotmc.org/resources/nameless-plugin-for-v2.59032/)
- Create connections to connect your minecraft servers to the Store on StaffCP -> Connections
- Create products and you can now assign connections to the products that actions will execute on all connections
- Now create actions on the product to execute commands when someone purchase your product

## Patreon
If you like to help out with the development and get early access to new updates and new modules check out [https://partydragen.com/patreon/](https://partydragen.com/patreon/)

## NamelessHosting:
Create your own free NamelessMC website at NamelessHosting for free at [https://namelesshosting.com](https://namelesshosting.com/)

## Contact me:
- Discord: [https://discord.gg/cY5Yfzd](https://discord.gg/cY5Yfzd)
- Website: [https://partydragen.com](https://partydragen.com)
